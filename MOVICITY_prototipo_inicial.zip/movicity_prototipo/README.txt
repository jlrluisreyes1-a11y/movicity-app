MOVICITY CORPORATION - PROTOTIPO INICIAL

Contenido:
- index.html: panel web demostrativo, adaptable a computadora y celular.

Cómo probarlo:
1. Descomprime el archivo ZIP.
2. Abre index.html en un navegador para revisar el prototipo.

Cómo subirlo a GitHub:
1. Entra al repositorio movicity-app.
2. Pulsa Add file > Upload files.
3. Arrastra index.html y README.txt (o sus archivos descomprimidos) a la página.
4. Pulsa Commit changes.

Importante:
Este prototipo utiliza datos de demostración guardados temporalmente en la página. No está conectado a Supabase, GPS, autenticación real, pagos, notificaciones ni despacho automático. No usar con datos personales reales ni para operar viajes reales. La siguiente etapa es implementar backend, autenticación y permisos seguros.
